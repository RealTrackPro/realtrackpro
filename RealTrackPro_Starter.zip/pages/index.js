
export default function Home() {
  return (
    <div>
      <h1>Welcome to RealTrackPro</h1>
      <p>This is the starter launch version of the platform.</p>
    </div>
  );
}
